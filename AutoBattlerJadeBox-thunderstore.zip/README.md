# Auto-Battler-Jade-Box  
Inspired by auto battle mods from Slay the Spire, this mod adds a Jade Box option that makes combats (semi)automatic.  
Unless you have cards or exhibits that require choosing the options, combats will be full auto.  
Spell Cards are activated when you're about to be defeated.

Installation(Github): Download AutoBattlerJadeBox.dll and place it to Steam\steamapps\common\LBoL\BepInEx\plugins

Credit:  
Lost Branch of Legend by Alioth Studio  
TASBot by dwangoAC
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746